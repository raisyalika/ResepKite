<?php    
    session_start();

    // Menyambungkan ke database resepkite
    $conn = mysqli_connect("localhost", "root", "", "resepkite")
        // Jika gagal terkoneksi, tampilkan pesan error 
        or die("Connect failed: %s\n". $conn -> error);

    // Menjalankan fungsi Query SQL pada database dan mengembalikan hasilnya dalam bentuk array
    function query($query){
        global $conn; // Variabel $conn untuk menghubungkan ke database
        $result = mysqli_query($conn, $query); // Hasil query disimpan dalam variabel result
        $rows = [];
        while($row = mysqli_fetch_assoc($result)){
            $rows[] = $row;
        }
        return $rows;
    }

    if (isset($_SESSION['username'])) {
        $username = $_SESSION['username'];

        // Query untuk mendapatkan id_user berdasarkan username yang sedang login
        $query = "SELECT id_user FROM user WHERE username='$username'";
        $result = mysqli_query($conn, $query);

        if ($result && mysqli_num_rows($result) > 0) {
            // Ambil id_user dari hasil query
            $row = mysqli_fetch_assoc($result);
            $id_user = $row['id_user'];

            // Query untuk mendapatkan resep berdasarkan id_user yang sedang login
            $resep = query("SELECT * FROM resep WHERE id_user='$id_user'");
        } else {
            // Jika tidak ditemukan user dengan username tersebut, lakukan penanganan sesuai kebutuhan
            header("Location: login.php");
            exit();
        }
    } else {
        // Arahkan pengguna ke halaman utama atau halaman lain yang sesuai
        header("Location: login.php");
        exit();
    }
?>


<HTML>
<HEAD>
    <link rel="icon" href="logo.png">
    <title>Resep Kite</title>
    <style>
        *{
            position: relative;
            font-family: sans-serif;
            margin: 0;
        }
        a:hover{ color: dimgray;}
        img{ object-fit: cover;}
    /*Layar Responsif*/
        @media (max-width: 799px){
            .header {padding: 5px 5px}
        }
        

    /*Header */
        .header{
            text-align: center;
            display: grid;
            grid-template-columns: 1fr 1fr;
            background-color: #2c5c46;
            padding: 10px 10px;
        }
        nav ul{
            font-weight: lighter;
            font-size: large;
            list-style: none;
            margin: 0;
            padding-top: 20;
            display: flex;
            justify-content: space-between;
        }
        nav a{
            color: lightgray;
            text-decoration: none;
        }
        .header .kiri .logo{
            margin-left: 40px;
            float: left;
            width: 75;
            padding-bottom: 10;
        }
        .body{
            display: grid;
            grid-template-columns: 863px 300px;
            margin: 25 0 10 50;
        }
    /*Daftar Resep*/
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: center;
            border: 1px solid #ddd;
        }
        .foto-resep {
            height: 150px;
            width: 150px;
        }
    /*Footer */
        .footer{
            text-align: center;
            background-color: #2c5c46;
            font: arial;
            color: white;
            padding: 0.5cm 2.5cm;
        }
    </style>
</HEAD>
<BODY>
    <!--Header dan Navigasi Bar-->
    <div class="header">
        <div class="kiri">
            <img class="logo" src="logo.png">
        </div>
        <div class="kanan">
            <nav><ul>
                <!--karena user telah login, maka ketika kembali ke dashboard
                akan menggunakan file dashboard.php-->
                <div class="dashboard"><a href="dashboard.php">Dashboard</a></div>
                <div class="resepw"><a href="resepw.php">Resep W</a></div>
                <div class="upload"><a href="upload.php">Upload</a></div>
                <div class="profile"><a href="profile.php">Profile</a></div>
                <div></div>
            </ul></nav>
        </div>
    </div>
    <div class="body">
        <!--Daftar Resep-->
        <div class="kiri">
            <p style="font-size: 35px; margin-bottom: 8;">
                <b>Daftar Resep</b></p>
            <p style="color: dimgray">
                Upload resep terbaikmu sekarang!</p><br><br>
            <table>
                <thead>
                <tr>
                    <th>No.</th>
                    <th>Nama Resep</th>
                    <th>Foto Resep</th>
                    <th>Kategori</th>
                    <th>Jumlah Porsi</th>
                    <th>Edit</th>
                </tr>
                </thead>
                <tbody>
                    <tr>
                    <?php $i = 1; ?>
                    <?php foreach($resep as $row): ?>
                    <tr>
                        <td><?php echo $i ?></td>
                        <td><?php echo $row["nama_resep"]; ?></td>
                        <td><img class="foto-resep" src="fotoresep/<?= $row["fotoresep"]; ?>"></td>
                        <td><?php echo $row["kategori"]; ?></td>
                        <td><?php echo $row["jmlh_porsi"]; ?></td>
                        <td>
                            <a href="editresep.php?id_resep=<?= $row["id_resep"]; ?>">Edit</a>
                            <a href="deleteresep.php?id_resep=<?= $row["id_resep"]; ?>">| Hapus</a>
                        </td>
                    </tr>
                    <?php $i++; ?>
                    <?php endforeach; ?>
                    </tr>
                </tbody>
            </table>
            <br><br>
        </div>
        <div class="kanan"> </div>
    </div>
    <!--Footer-->
    <div class="footer">
        <p>&copy;2023 Resep Kite. All rights reserved.</p>
    </div>
</BODY>
</HTML>