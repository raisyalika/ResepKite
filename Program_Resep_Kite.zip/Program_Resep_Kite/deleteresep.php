<?php
    session_start();

    // Menyambungkan ke database resepkite
    $conn = mysqli_connect("localhost", "root", "", "resepkite")
        // Jika gagal terkoneksi, tampilkan pesan error 
        or die("Connect failed: %s\n". $conn -> error);

    // Memeriksa apakah parameter id_resep ada dalam URL
    if (isset($_GET['id_resep'])) {
        $id_resep = $_GET['id_resep'];
        
        // Query untuk mengambil informasi resep berdasarkan id_resep
        $query = "SELECT * FROM resep WHERE id_resep = $id_resep";
        $result = mysqli_query($conn, $query);
        $row = mysqli_fetch_assoc($result);
    } else {
        echo "ID Resep tidak tersedia.";
    }

    function hapus($id_resep){
        global $conn;
        mysqli_query($conn, "DELETE FROM resep WHERE id_resep = $id_resep");
        return mysqli_affected_rows($conn);
    }

    $id_resep = $_GET["id_resep"];
    if( hapus($id_resep) > 0){
        echo "
            <script>
                alert('Data berhasil dihapus!');
                document.location.href = 'resepw.php';
            </script>
        ";
    } else {
        echo "<script>
        alert('Data gagal dihapus!');
        document.location.href = 'resepw.php';
        </script>
        ";
    }
?>