<?php
    session_start();

    // Menyambungkan ke database resepkite
    $conn = mysqli_connect("localhost", "root", "", "resepkite")
        // Jika gagal terkoneksi akan menampilkan pesan error 
        or die("Connect failed: %s\n". $conn->error);

    // Mendapatkan data user dari database
    $username = $_SESSION['username'] ?? ''; // Mengambil username dari sesi
    $query = "SELECT * FROM user WHERE username = '$username'"; // Menggunakan username dari sesi
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    $id_user = $_SESSION["id_user"]; // Mengambil id_user dari session

    $query = "SELECT * FROM user WHERE id_user = $id_user"; // Query untuk mendapatkan informasi user
    $user = query($conn, $query)[0]; // Mengambil data user dari hasil query

    function query($conn, $query){
        $result = mysqli_query($conn, $query);
        $rows = [];
        while($row = mysqli_fetch_assoc($result)){
            $rows[] = $row;
        }
        return $rows;
    }

    // Fungsi untuk menampilkan data user pada form profil
    function displayProfileData($field)
    {
        global $row;
        echo $row[$field] ?? '';
    }
?>

<HEAD>
    <link rel="icon" href="logo.png">
    <title>Resep Kite</title>
    <style>
        *{
            position: relative;
            font-family: sans-serif;
            margin: 0;
        }
        a:hover{ color: dimgray;}
    /*Layar Responsif*/
        @media (max-width: 799px){
            .header {padding: 5px 5px}
        }
    /*Header */
        .header{
            text-align: center;
            display: grid;
            grid-template-columns: 1fr 1fr;
            background-color: #2c5c46;
            padding: 10px 10px;
        }
        nav ul{
            font-weight: lighter;
            font-size: large;
            list-style: none;
            margin: 0;
            padding-top: 20;
            display: flex;
            justify-content: space-between;
        }
        nav a{
            color: lightgray;
            text-decoration: none;
        }
        .header .kiri .logo{
            margin-left: 40px;
            float: left;
            width: 75;
            padding-bottom: 10;
        }
    /*Profil*/
        .gambar-profile{
            width: 650px;
            height: 400px;
            object-fit: cover;
            margin-left: 1cm;
            border-radius: 50px;
        }
        .konten-profil{
            width: 350px;
            background-color: #fff;
            border: 1px solid #dbdbdb;
            padding: 20px;
            border-radius: 6px;
            margin-left: 25%;
        }
        .error{
            color: red;
            margin-bottom: 15px;
        }
        /*Form Profil*/
        form{ margin-top: 20px;}
        input[type="submit"]{
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 15px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            background-color: #2c5c46;
            color: #fff;
        }
        input[type="submit"]:hover{
            background-color: #0080e6;
        }
        form a{
            color: #2c5c46;
            text-decoration: none;
            font-family: Arial, sans-serif;
            font-size: 14px;
            font-weight: 600;
            width: 100%;
            padding: 10px;
            cursor: pointer;
        }
        .delete{
            width: 100%;
            padding: 10px;
            border: 1px solid #dbdbdb;
            border-radius: 15px;
            margin-bottom: 15px;
            text-decoration: none;
            color: #2c5c46;
        }
    /*Footer */
        .footer{
            text-align: center;
            background-color: #2c5c46;
            font: arial;
            color: white;
            padding: 0.5cm 2.5cm;
        }
    </style>
</HEAD>
<BODY>
    <!--Header dan Navigasi Bar-->
    <div class="header">
        <div class="kiri">
            <img class="logo" src="logo.png">
        </div>
        <div class="kanan">
            <nav><ul>
                <!--karena user telah login, maka ketika kembali ke dashboard
                akan menggunakan file dashboard.php-->
                <div class="dashboard"><a href="dashboard.php">Dashboard</a></div>
                <div class="resepw"><a href="resepw.php">Resep W</a></div>
                <div class="upload"><a href="upload.php">Upload</a></div>
                <div class="profile"><a href="profile.php">Profile</a></div>
                <div></div>
            </ul></nav>
        </div>
    </div>
    <!--Daftar-->
    <div style="margin: 1cm 0 1cm;">
        <table><tr>
            <td>
                <img class="gambar-profile" src="fotoprofile/<?= $user["foto"]; ?>">
            </td>
            <td>
                <div class="konten-profil">
                    <h2 style="text-align: center";>Informasi Profil</h2>
                    <div class="error">
                        <?php
                        //cek apakah terdapat cookie dengan nama message
                        if(isset($_COOKIE["message"])){
                            //jika ada tampilkan pesannya
                            echo $_COOKIE["message"];
                        }
                        ?>
                    </div>
                    <!--data ditampilkan sesuai database-->
                    <form method="post" action="editprofile.php">
                        <label>Nama <span style="margin-right: 47px;"></span>: <?php displayProfileData('name'); ?></label><br><br>
                        <label>Username <span style="margin-right: 16px;"></span>: <?php displayProfileData('username'); ?></label><br><br>
                        <label>Email <span style="margin-right: 50px;"></span>: <?php displayProfileData('email'); ?></label><br><br>
                        <label>Password <span style="margin-right: 20px;"></span>: <?php displayProfileData('password'); ?></label><br><br>
                        <input type="submit" name="edit" value="Ubah Data"><a href="editprofile.php"></a>
                    </form>
                    <form method="post" action="index.php">
                        <input type="submit" name="Logout" value="Logout"><a href="logout.php"></a><br>
                    </form><br>
                    <a class="delete" href="deleteakun.php?id_user=<?= $row["id_user"]; ?>">Delete Akun</a><br>
                </div>
            </td>
        </tr></table>
    </div>
    <!--Footer-->
    <div class="footer">
        <p>&copy;2023 Resep Kite. All rights reserved.</p>
    </div>
</BODY>
</HTML>