<?php
session_start();

// Menyambungkan ke database resepkite
$conn = mysqli_connect("localhost", "root", "", "resepkite") 
    or die("Connect failed: " . mysqli_connect_error());

if (isset($_GET['id_resep'])) {
    $_SESSION['id_resep'] = $_GET['id_resep'];
}

$id_resep = $_SESSION["id_resep"] ?? ""; // Mengambil id_resep dari session

// Query untuk mendapatkan informasi resep
$query = "SELECT * FROM resep WHERE id_resep = $id_resep";
$resep = query($conn, $query)[0]; // Mengambil data resep dari hasil query

function query($conn, $query)
{
    $result = mysqli_query($conn, $query);
    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }
    return $rows;
}

function update($conn, $data)
{
    $id_resep = $data["id_resep"];
    $nama_resep = htmlspecialchars($data["nama_resep"]);
    $kategori = htmlspecialchars($data["kategori"]);
    $jmlh_porsi = htmlspecialchars($data["jmlh_porsi"]);
    $bahan = htmlspecialchars($data["bahan"]);
    $langkah = htmlspecialchars($data["langkah"]);

    $query = "UPDATE resep 
              SET nama_resep = '$nama_resep', 
                  kategori = '$kategori',
                  jmlh_porsi = '$jmlh_porsi', 
                  bahan = '$bahan',
                  langkah = '$langkah'
              WHERE id_resep = $id_resep";

    mysqli_query($conn, $query) or die("Query failed: " . mysqli_error($conn));
    return mysqli_affected_rows($conn);
}

if (isset($_POST["update"])) {
    $data = [
        "id_resep" => $id_resep,
        "nama_resep" => $_POST["nama_resep"],
        "kategori" => $_POST["kategori"],
        "jmlh_porsi" => $_POST["jmlh_porsi"],
        "bahan" => $_POST["bahan"],
        "langkah" => $_POST["langkah"]
    ];

    $result = update($conn, $data);
    // Upload dan update foto resep jika ada file foto baru diunggah
    if (isset($_FILES["fotoresep"]) && $_FILES["fotoresep"]["error"] == 0) {
        $fotoresep_name = $_FILES["fotoresep"]["name"];
        $fotoresep_tmp = $_FILES["fotoresep"]["tmp_name"];
        $fotoresep_path = "fotoresep/" . $fotoresep_name;
        move_uploaded_file($fotoresep_tmp, $fotoresep_path);

        $query = "UPDATE resep SET fotoresep = '$fotoresep_name' WHERE id_resep = $id_resep";
        mysqli_query($conn, $query) or die("Query failed: " . mysqli_error($conn));
    }

    if ($result > 0) {
        echo "<script>alert('Resep berhasil diperbarui');</script>";
                    echo "<meta http-equiv='refresh' content='0;url=resepw.php'>";
                } else {
                    echo"<script>alert('Resep Gagal diperbarui');</script>";
                }
}
?>


<HTML>
<HEAD>
    <link rel="icon" href="logo.png">
    <title>Resep Kite</title>
    <style>
        *{
            position: relative;
            font-family: sans-serif;
            margin: 0;
        }
        a:hover{ color: dimgray;}
        img{ object-fit: cover;}
    /*Layar Responsif*/
        @media (max-width: 799px){
            .header {padding: 5px 5px}
        }
    /*Header */
        .header{
            text-align: center;
            display: grid;
            grid-template-columns: 1fr 1fr;
            background-color: #2c5c46;
            padding: 10px 10px;
        }
        nav ul{
            font-weight: lighter;
            font-size: large;
            list-style: none;
            margin: 0;
            padding-top: 20;
            display: flex;
            justify-content: space-between;
        }
        nav a{
            color: lightgray;
            text-decoration: none;
        }
        .header .kiri .logo{
            margin-left: 40px;
            float: left;
            width: 75;
            padding-bottom: 10;
        }
        body{
            background-image: url("espisang.jpeg");
            background-repeat: no-repeat;
            background-position: 100% auto;
            background-size: cover;
        }
    /*form*/
        .form_upload{
            margin: 20px auto;
            height: auto;
            width: 700px;
            padding: 10px;
            border: 0.5px solid #ccc;
            background-color: #23382f54;
            border-radius: 20px;
            font-weight: bolder;
        }
        .header_upload{
            color: #ffffff;
            text-align: center;
            font-size: 35;
            font-weight: bold;
            padding: 15px 0 15px 0;
        }
        .tabel_upload{
            margin:0 auto;
            padding: 15px;
        }
        input[type=text] {
            border: 0.5px;
            border-radius: 10px;
            width: 100%;
            padding: 10px;
        }
        .uploadbutton{
            width: 100%;
            padding: 10px;
            border: white;
            border-radius: 15px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            background-color: #2c5c46;
            color: #fff;
        }
        .uploadname{
            color: #ffffff;
            margin: auto;
            text-align: left;
            font-weight: bolder;
        }
        textarea{
            border: 0.5px;
            border-radius: 15px;
        }
        .desc{
            color: white;
            font-size: 15px;
        }
    /*Footer */
    .footer{
            text-align: center;
            background-color: #2c5c46;
            font: arial;
            color: white;
            padding: 0.5cm 2.5cm;
        }
    </style>
</HEAD>
<BODY>
    <!--Header dan Navigasi Bar-->
    <div class="header">
        <div class="kiri">
            <img class="logo" src="logo.png">
        </div>
        <div class="kanan">
            <nav><ul>
                <!--karena user telah login, maka ketika kembali ke dashboard
                akan menggunakan file dashboard.php-->
                <div class="dashboard"><a href="dashboard.php">Dashboard</a></div>
                <div class="resepw"><a href="resepw.php">Resep W</a></div>
                <div class="upload"><a href="upload.php">Upload</a></div>
                <div class="profile"><a href="profile.php">Profile</a></div>
                <div></div>
            </ul></nav>
        </div>
    </div>
    <!--Form Upload-->
    <div class="form_upload">
    <form method="post" action="" text-align="center" enctype="multipart/form-data">
            <div class="header_upload">Edit Resep</div>
            <br>
            <div class="tabel_upload">
                <table width="600" border="0" cellspacing="1" cellpadding="2">
                    <tr>
                        <td class="uploadname" width="250">Nama Resep</td>
                        <td>
                            <input name="nama_resep" type="text" id="nama_resep"
                                value="<?= $resep["nama_resep"]; ?> ">
                        </td>
                    </tr>
                    <tr>
                        <td class="uploadname" width="250">Kategori</td>
                        <td><input name="kategori" type="text" id="kategori"
                            value="<?= $resep["kategori"]; ?> "></td>
                    </tr>
                    <tr>
                        <td> </td>
                        <td class="desc">Kategori dapat berupa: <br>
                            (1) Main Course, (2) Appetizers, <br> 
                            (3) Desserts, (4) Drinks.
                        </td>
                    </tr>
                    <tr>
                        <td class="uploadname" width="250">Jumlah Porsi</td>
                        <td>
                            <input name="jmlh_porsi" type="text" id="jmlh_porsi"
                                value="<?= $resep["jmlh_porsi"]; ?> ">
                        </td>
                    </tr>
                    <tr>
                        <td class="uploadname">Bahan - Bahan</td>
                        <td><textarea name="bahan" id="bahan" rows="8" cols="50">  <?= $resep["bahan"]; ?></textarea></td>
                    </tr>
                    <tr>
                        <td class="uploadname">Langkah - Langkah</td>
                        <td><textarea name="langkah" id="langkah" rows="8" cols="50">  <?= $resep["langkah"]; ?></textarea></td>
                    </tr>
                    <tr>
                        <td class="uploadname" width="250">Gambar Resep</td>
                        <td>
                        <input type="file" id="fotoresep" name="fotoresep">
                        </td>
                    </tr>
                    <tr>
                        <td width="250"> </td>
                        <td> </td>
                    </tr>
                    <tr>
                        <td width="250"> </td>
                        <td>
                            <br><input type="submit" class="uploadbutton" value="Ubah Resep" name="update" id="update">
                        </td>
                    </tr>
                </table>
            </div>
        </form>
    </div>
    <!--Footer-->
    <div class="footer">
        <p>&copy;2023 Resep Kite. All rights reserved.</p>
    </div>
</BODY>
</HTML>