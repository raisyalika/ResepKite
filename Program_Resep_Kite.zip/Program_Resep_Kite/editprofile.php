<?php
    session_start();

    // Menyambungkan ke database resepkite
    $conn = mysqli_connect("localhost", "root", "", "resepkite")
        // Jika gagal terkoneksi akan menampilkan pesan error 
        or die("Connect failed: %s\n". $conn->error);
        
    $id_user = $_SESSION["id_user"]; // Mengambil id_user dari session

    $query = "SELECT * FROM user WHERE id_user = $id_user"; // Query untuk mendapatkan informasi user
    $user = query($conn, $query)[0]; // Mengambil data user dari hasil query

    function query($conn, $query){
        $result = mysqli_query($conn, $query);
        $rows = [];
        while($row = mysqli_fetch_assoc($result)){
            $rows[] = $row;
        }
        return $rows;
    }

    function update($conn, $data){
        $id_user = $data["id_user"];
        $name = htmlspecialchars($data["name"]);
        $email = htmlspecialchars($data["email"]);
        $username = htmlspecialchars($data["username"]);
        $password = htmlspecialchars($data["password"]);

        $query = "UPDATE user SET
            name = '$name', 
            email = '$email',
            username = '$username', 
            password = '$password'
            WHERE id_user = $id_user";

        mysqli_query($conn, $query) or die("Query failed: " . mysqli_error($conn));
        return mysqli_affected_rows($conn);
    }

    if (isset($_POST["submit"])) {
        $data = [
            "id_user" => $id_user,
            "name" => $_POST["name"],
            "email" => $_POST["email"],
            "username" => $_POST["username"],
            "password" => $_POST["password"]
        ];

        $result = update($conn, $data);
        if ($result > 0) {
            echo "<script>alert('Data berhasil diperbarui');</script>";
                    echo "<meta http-equiv='refresh' content='0;url=profile.php'>";
                } else {
                    echo"<script>alert('Akun Gagal diperbarui');</script>";
                }
        
        // Upload dan update foto profile jika ada file foto baru diunggah
        if ($_FILES["foto"]["error"] == 0) {
            $foto_name = $_FILES["foto"]["name"];
            $foto_tmp = $_FILES["foto"]["tmp_name"];
            $foto_path = "fotoprofile/" . $foto_name;
            move_uploaded_file($foto_tmp, $foto_path);
            
            $query = "UPDATE user SET foto = '$foto_name' WHERE id_user = $id_user";
            mysqli_query($conn, $query) or die("Query failed: " . mysqli_error($conn));
        }
    }
?>

<HTML>
<HEAD>
    <link rel="icon" href="logo.png">
    <title>Resep Kite</title>
    <style>
        * {
            position: relative;
            font-family: sans-serif;
            margin: 0;
        }
        a:hover { color: dimgray;}
        /*Layar Responsif*/
        @media (max-width: 799px) {
            .header {
                padding: 5px 5px
            }
        }
        /*Header */
        .header {
            text-align: center;
            display: grid;
            grid-template-columns: 1fr 1fr;
            background-color: #2c5c46;
            padding: 10px 10px;
        }
        nav ul {
            font-weight: lighter;
            font-size: large;
            list-style: none;
            margin: 0;
            padding-top: 20;
            display: flex;
            justify-content: space-between;
        }
        nav a {
            color: lightgray;
            text-decoration: none;
        }
        .header .kiri .logo {
            margin-left: 40px;
            float: left;
            width: 75;
            padding-bottom: 10;
        }
        /*Update*/
        .gambar-update {
            width: 650px;
            height: 400px;
            object-fit: cover;
            margin-left: 1cm;
            border-radius: 50px;
        }
        .konten-update {
            width: 350px;
            background-color: #fff;
            border: 1px solid #dbdbdb;
            padding: 20px;
            border-radius: 6px;
            margin-left: 25%;
        }
        .error {
            color: red;
            margin-bottom: 15px;
        }
        /*Form Update*/
        form {
            margin-top: 20px;
        }
        input[type="text"],
        input[type="password"],
        input[type="file"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #dbdbdb;
            border-radius: 15px;
            margin-bottom: 15px;
        }
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 15px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            background-color: #2c5c46;
            color: #fff;
        }
        input[type="submit"]:hover {
            background-color: #0080e6;
        }
        form a {
            color: #2c5c46;
            text-decoration: none;
            font-family: Arial, sans-serif;
            font-size: 14px;
            font-weight: 600;
            width: 100%;
            padding: 10px;
            cursor: pointer;
        }
        /*Footer */
        .footer {
            text-align: center;
            background-color: #2c5c46;
            font: arial;
            color: white;
            padding: 0.5cm 2.5cm;
        }
    </style>
</HEAD>

<BODY>
    <!--Header dan Navigasi Bar-->
    <div class="header">
        <div class="kiri">
            <img class="logo" src="logo.png">
        </div>
        <div class="kanan">
            <nav>
                <ul>
                    <!--karena user telah login, maka ketika kembali ke dashboard
                akan menggunakan file dashboard.php-->
                    <div class="dashboard"><a href="dashboard.php">Dashboard</a></div>
                    <div class="resepw"><a href="resepw.php">Resep W</a></div>
                    <div class="upload"><a href="upload.php">Upload</a></div>
                    <div class="profile"><a href="profile.php">Profile</a></div>
                    <div></div>
                </ul>
            </nav>
        </div>
    </div>
    <!--Update-->
    <div style="margin: 0.5cm 0 0.5cm;">
        <table><tr>
            <td>
                <img class="gambar-update" src="fotoprofile/<?= $user["foto"]; ?>">
            </td>
            <td>
                <div class="konten-update">
                    <h2 style="text-align: center;">Update Profile</h2>
                    <div class="error">
                        <?php
                        //cek apakah terdapat cookie dengan nama message
                        if(isset($_COOKIE["message"])){
                            //jika ada tampilkan pesannya
                            echo $_COOKIE["message"];
                        }
                        ?>
                    </div>
                    <form method="post" action="" text-align="center" enctype="multipart/form-data">
                        <label for="name">Nama</label>
                        <input type="text" name="name" id="name" required value="<?= $user["name"]; ?> ">

                        <label for="email">Email</label>
                        <input type="text" name="email" id="email" value="<?= $user["email"]; ?> ">

                        <label for="foto">Foto Profile</label>
                        <input type="file" name="foto" id="foto" accept="image/*">

                        <label for="username">Username</label>
                        <input type="text" name="username" id="username" required value="<?= $user["username"]; ?> ">

                        <label for="email">Password</label>
                        <input type="text" name="password" id="password" value="<?= $user["password"]; ?> ">

                        <input type="submit" name="submit" value="Edit">
                    </form>
                </div>
            </td>
        </tr></table>
    </div>
    <!--Footer-->
    <div class="footer">
        <p>&copy;2023 Resep Kite. All rights reserved.</p>
    </div>
</BODY>
</HTML>