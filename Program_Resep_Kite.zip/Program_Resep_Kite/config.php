<?php
    session_start();

    //menyambungkan ke database resepkite
    $conn = mysqli_connect("localhost", "root", "", "resepkite")
        //jika gagal terkoneksi akan menampilkan pesan error 
        or die("Connect failed: %s\n". $conn -> error);

    //menjalankan fungsi Query SQL pada database dan mengembalikan hasilnya dalam bentuk array
    function query($query){
        global $conn; //variabel $conn untuk menghubungkan ke database
        $result = mysqli_query($conn, $query); //hasil query disimpan dalam variabel result
        $rows = [];
        while($row = mysqli_fetch_assoc($result)){
            $rows[] = $row;
        }
        return $rows;
    }

    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username != '' && $password != '') {
        $sql = "SELECT * FROM user WHERE username='$username' AND password='$password'";
        $query = mysqli_query($conn, $sql);
        $data = mysqli_fetch_assoc($query);
        
        if (mysqli_num_rows($query) < 1) {
            setcookie("message", "Maaf, username atau password salah", time()+60);
            header("location: login.php");
        } else {
            echo $data['username'] . $data['password'];
            $_SESSION['username'] = $data['username']; // set session username
            $_SESSION['nama'] = $data['nama']; // set session nama
            $_SESSION['id_user'] = $data['id_user'];
            header("location: dashboard.php");
        }
    } else {
        setcookie("message", "Username atau Password kosong", time()+60);
        header("location: login.php"); 
    }
?>