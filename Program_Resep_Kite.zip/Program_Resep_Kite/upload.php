<?php
session_start();

// Menyambungkan ke database resepkite
$conn = mysqli_connect("localhost", "root", "", "resepkite")
    // Jika gagal terkoneksi akan menampilkan pesan error
    or die("Connect failed: %s\n". $conn -> error);

// Menjalankan fungsi Query SQL pada database dan mengembalikan hasilnya dalam bentuk array
function query($query){
    global $conn; // Variabel $conn untuk menghubungkan ke database
    $result = mysqli_query($conn, $query); // Hasil query disimpan dalam variabel result
    $rows = [];
    while($row = mysqli_fetch_assoc($result)){
        $rows[] = $row;
    }
    return $rows;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_resep = $_POST['nama_resep'];
    $kategori = $_POST['kategori'];
    $jmlh_porsi = $_POST['jmlh_porsi'];
    $bahan = $_POST['bahan'];
    $langkah = $_POST['langkah'];

    // Validasi inputan kosong
    if (empty($nama_resep) || empty($kategori) || empty($jmlh_porsi) || empty($bahan) || empty($langkah)) {
        echo "<script>alert('Semua field harus diisi');</script>";
    } else {
        // Mendapatkan id_user dari session
        $id_user = $_SESSION['id_user'];

        $fotoresep = upload();

        // Menyimpan data resep ke database
        $insertQuery = "INSERT INTO resep (id_user, nama_resep, kategori, jmlh_porsi, bahan, langkah, fotoresep) 
        VALUES ('$id_user', '$nama_resep', '$kategori', '$jmlh_porsi', '$bahan', '$langkah', '$fotoresep')";
        if (mysqli_query($conn, $insertQuery)) {
            echo "<script>alert('Resep Berhasil Ditambahkan');</script>";
            echo "<meta http-equiv='refresh' content='0;url=resepw.php'>";
        } else {
            echo "Error : " . mysqli_error($conn);
}
    }
    }


function upload()
{
    $namaFile = $_FILES['fotoresep']['name'];
    $ukuranFile = $_FILES['fotoresep']['size'];
    $error = $_FILES['fotoresep']['error'];
    $tmpName = $_FILES['fotoresep']['tmp_name'];

    // Cek apakah ada gambar yang diupload
    if ($error === 4) {
        echo "<script>alert('Silakan pilih foto resep');</script>";
        return false;
    }

    // Cek apakah yang diupload adalah gambar
    $ekstensiGambarValid = ['jpg', 'jpeg', 'png'];
    $ekstensiGambar = strtolower(pathinfo($namaFile, PATHINFO_EXTENSION));
    if (!in_array($ekstensiGambar, $ekstensiGambarValid)) {
        echo "<script>alert('Format foto tidak valid. Gunakan format JPG, JPEG, atau PNG');</script>";
        return false;
    }

    // Cek ukuran file gambar
    if ($ukuranFile > 5000000) {
        echo "<script>alert('Ukuran foto terlalu besar. Maksimal 5MB');</script>";
        return false;
    }

    // Generate nama file baru agar tidak ada file dengan nama yang sama
    $namaFileBaru = uniqid() . '.' . $ekstensiGambar;

    // Upload gambar ke folder yang diinginkan
    move_uploaded_file($tmpName, 'fotoresep/' . $namaFileBaru);

    return $namaFileBaru;
}
?>


<HTML>
<HEAD>
    <link rel="icon" href="logo.png">
    <title>Resep Kite</title>
    <style>
        *{
            position: relative;
            font-family: sans-serif;
            margin: 0;
        }
        a:hover{ color: dimgray;}
        img{ object-fit: cover;}
    /*Layar Responsif*/
        @media (max-width: 799px){
            .header {padding: 5px 5px}
        }
    /*Header */
        .header{
            text-align: center;
            display: grid;
            grid-template-columns: 1fr 1fr;
            background-color: #2c5c46;
            padding: 10px 10px;
        }
        nav ul{
            font-weight: lighter;
            font-size: large;
            list-style: none;
            margin: 0;
            padding-top: 20;
            display: flex;
            justify-content: space-between;
        }
        nav a{
            color: lightgray;
            text-decoration: none;
        }
        .header .kiri .logo{
            margin-left: 40px;
            float: left;
            width: 75;
            padding-bottom: 10;
        }
        body{
            background-image: url("espisang.jpeg");
            background-repeat: no-repeat;
            background-position: 100% auto;
            background-size: cover;
        }
    /*form*/
        .form_upload{
            margin: 20px auto;
            height: auto;
            width: 700px;
            padding: 10px;
            border: 0.5px solid #ccc;
            background-color: #23382f54;
            border-radius: 20px;
            font-weight: bolder;
        }
        .header_upload{
            color: #ffffff;
            text-align: center;
            font-size: 35;
            font-weight: bold;
            padding: 15px 0 15px 0;
        }
        .tabel_upload{
            margin:0 auto;
            padding: 15px;
        }
        input[type=text], input[type=number]{
            border: 0.5px;
            border-radius: 10px;
            width: 100%;
            padding: 10px;
        }
        .uploadbutton{
            width: 100%;
            padding: 10px;
            border: white;
            border-radius: 15px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            background-color: #2c5c46;
            color: #fff;
        }
        .uploadname{
            color: #ffffff;
            margin: auto;
            text-align: left;
            font-weight: bolder;
        }
        .radiobutton{
            color: white;
            font-size: 15;
        }
        textarea{
            border: 0.5px;
            border-radius: 15px;
        }
        .desc{
            color: white;
            font-size: 15px;
        }
    /*Footer */
    .footer{
            text-align: center;
            background-color: #2c5c46;
            font: arial;
            color: white;
            padding: 0.5cm 2.5cm;
        }
    </style>
</HEAD>
<BODY>
    <!--Header dan Navigasi Bar-->
    <div class="header">
        <div class="kiri">
            <img class="logo" src="logo.png">
        </div>
        <div class="kanan">
            <nav><ul>
                <!--karena user telah login, maka ketika kembali ke dashboard
                akan menggunakan file dashboard.php-->
                <div class="dashboard"><a href="dashboard.php">Dashboard</a></div>
                <div class="resepw"><a href="resepw.php">Resep W</a></div>
                <div class="upload"><a href="upload.php">Upload</a></div>
                <div class="profile"><a href="profile.php">Profile</a></div>
                <div></div>
            </ul></nav>
        </div>
    </div>
    <!--Form Upload-->
    <div class="form_upload">
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">
            <div class="header_upload">Upload Resep</div>
            <br>
            <div class="tabel_upload">
                <table width="600" border="0" cellspacing="1" cellpadding="2">
                    <tr>
                        <td class="uploadname" width="250">Nama Resep</td>
                        <td><input name="nama_resep" type="text" id="namaresep"></td>
                    </tr>
                    <tr>
                        <td class="uploadname" width="250">Kategori</td>
                        <td><input name="kategori" type="text" id="kategori"></td>
                    </tr>
                    <tr>
                        <td> </td>
                        <td class="desc">Kategori dapat berupa: <br>
                            (1) Main Course, (2) Appetizers, <br> 
                            (3) Desserts, (4) Drinks.
                        </td>
                    </tr>
                    <tr>
                        <td class="uploadname" width="250">Jumlah Porsi</td>
                        <td><input name="jmlh_porsi" type="text" id="jmlporsi"></td>
                    </tr>
                    <tr>
                        <td class="uploadname" width="250">Bahan - Bahan</td>
                        <td><textarea name="bahan" id="desc" rows="5" cols="50"></textarea></td>
                    </tr>
                    <tr>
                        <td class="uploadname" width="250">Langkah-Langkah</td>
                        <td><textarea name="langkah" id="desc" rows="5" cols="50"></textarea></td>
                    </tr>
                    <tr>
                        <td class="uploadname" width="250">Gambar Resep</td>
                        <td><input type="file" name="fotoresep" id="fotoresep" accept="image/*"></td>
                    </tr>
                    <tr>
                        <td width="250"></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td width="250"> </td>
                        <td><br><button class="uploadbutton" type="submit" name="upload" id="upload">Upload</button></td>
                    </tr>
                </table>
            </div>
        </form>
    </div>
    <!--Footer-->
    <div class="footer">
        <p>&copy;2023 Resep Kite. All rights reserved.</p>
    </div>
</BODY>
</HTML>