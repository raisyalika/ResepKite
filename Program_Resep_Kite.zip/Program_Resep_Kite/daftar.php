<?php
    session_start();
    
    // Menyambungkan ke database resepkite
    $conn = mysqli_connect("localhost", "root", "", "resepkite")
        // Jika gagal terkoneksi akan menampilkan pesan error 
        or die("Connect failed: %s\n". $conn -> error);

    // Menjalankan fungsi Query SQL pada database dan mengembalikan hasilnya dalam bentuk array
    function query($query){
        global $conn; // Variabel $conn untuk menghubungkan ke database
        $result = mysqli_query($conn, $query); // Hasil query disimpan dalam variabel result
        $rows = [];
        while($row = mysqli_fetch_assoc($result)){
            $rows[] = $row;
        }
        return $rows;
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {//
        $name = $_POST['name'];
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];

        // Validasi inputan kosong
        if (empty($name) || empty($username) || empty($email) || empty($password)) {
            echo "<script>alert('Semua field harus diisi');</script>";
        } else {
            $foto = upload();

            // Validasi apakah username atau email terdaftar
            $checkQuery = "SELECT * FROM user WHERE username = '$username' OR email = '$email'";
            $result = mysqli_query($conn, $checkQuery);
            if (mysqli_num_rows($result) > 0) {
                echo "<script>alert('Username atau Email sudah terdaftar');</script>";
            } else {
                // Menyimpan data profil akun ke database
                $insertQuery = "INSERT INTO user (name, username, email, password, foto) 
                    VALUES ('$name', '$username', '$email', '$password', '$foto')";
                if (mysqli_query($conn, $insertQuery)) {
                    echo "<script>alert('Akun Berhasil Dibuat');</script>";
                    echo "<meta http-equiv='refresh' content='0;url=login.php'>";//langsung ngelempar ke login pake meta karna di echo
                } else {
                    echo "Error : " . mysqli_error($conn);
                }
            }
        }
    }

    function upload()
    {
        $namaFile = $_FILES['foto']['name'];
        $ukuranFile = $_FILES['foto']['size'];
        $error = $_FILES['foto']['error'];
        $tmpName = $_FILES['foto']['tmp_name'];//tempat menyimpan foto sementara

        // Cek apakah ada gambar yang diupload
        if ($error === 4) {
            echo "<script>alert('Silakan pilih foto profile');</script>";
            return false;//tidak memproses data
        }

        // Cek apakah yang diupload adalah gambar
        $ekstensiGambarValid = ['jpg', 'jpeg', 'png'];
        $ekstensiGambar = strtolower(pathinfo($namaFile, PATHINFO_EXTENSION));
        if (!in_array($ekstensiGambar, $ekstensiGambarValid)) {
            echo "<script>alert('Format foto tidak valid. Gunakan format JPG, JPEG, atau PNG');</script>";
            return false;
        }

        // Cek ukuran file gambar
        if ($ukuranFile > 5000000) {
            echo "<script>alert('Ukuran foto terlalu besar. Maksimal 5MB');</script>";
            return false;
        }

        // Generate nama file baru agar tidak ada file dengan nama yang sama
        $namaFileBaru = uniqid() . '.' . $ekstensiGambar;

        // Upload gambar ke folder yang diinginkan
        move_uploaded_file($tmpName, 'fotoprofile/' . $namaFileBaru);

        return $namaFileBaru;
    }
?>

<HTML>
<HEAD>
    <link rel="icon" href="logo.png">
    <title>Resep Kite</title>
    <style>
        *{
            position: relative;
            font-family: sans-serif;
            margin: 0;
        }
        a:hover{ color: dimgray;}
    /*Layar Responsif*/
        @media (max-width: 799px){
            .header {padding: 5px 5px}
        }
    /*Header */
        .header{
            text-align: center;
            display: grid;
            grid-template-columns: 1fr 1fr;
            background-color: #2c5c46;
            padding: 10px 10px;
        }
        nav ul{
            font-weight: lighter;
            font-size: large;
            list-style: none;
            margin: 0;
            padding-top: 20;
            display: flex;
            justify-content: space-between;
        }
        nav a{
            color: lightgray;
            text-decoration: none;
        }
        .header .kiri .logo{
            margin-left: 40px;
            float: left;
            width: 75;
            padding-bottom: 10;
        }
    /*Daftar*/
        .gambar-daftar{
            width: 650px;
            height: 400px;
            object-fit: cover;
            margin-left: 1cm;
            border-radius: 50px
        }
        .konten-daftar{
            width: 350px;
            background-color: #fff;
            border: 1px solid #dbdbdb;
            padding: 20px;
            border-radius: 6px;
            margin-left: 25%;
        }
        .error{
            color: red;
            margin-bottom: 15px;
        }
        /*Form Daftar*/
        form{ margin-top: 20px;}
        input[type="text"], input[type="password"], input[type="file"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #dbdbdb;
            border-radius: 15px;
            margin-bottom: 15px;
        }
        input[type="submit"]{
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 15px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            background-color: #2c5c46;
            color: #fff;
        }
        input[type="submit"]:hover{
            background-color: #0080e6;
        }
        form a{
            color: #2c5c46;
            text-decoration: none;
            font-family: Arial, sans-serif;
            font-size: 14px;
            font-weight: 600;
            width: 100%;
            padding: 10px;
            cursor: pointer;
        }
        .foto-profile{
            color: #2c5c46;
            text-decoration: none;
            font-family: Arial, sans-serif;
            font-size: 14px;
            font-weight: 600;
            width: 100%;
            padding: 10px;
            cursor: pointer;
        }
    /*Footer */
        .footer{
            text-align: center;
            background-color: #2c5c46;
            font: arial;
            color: white;
            padding: 0.5cm 2.5cm;
        }
    </style>
</HEAD>
<BODY>
    <!--Header dan Navigasi Bar-->
    <div class="header">
        <div class="kiri">
            <img class="logo" src="logo.png">
        </div>
        <div class="kanan">
            <nav><ul>
                <div class="dashboard"><a href="index.php">Dashboard</a></div>
                <div class="login"><a href="login.php">Login</a></div>
                <div class="daftar"><a href="daftar.php">Daftar</a></div>
                <div></div>
            </ul></nav>
        </div>
    </div>
    <!--Daftar-->
    <div style="margin: 2cm 0 2cm;">
        <table><tr>
            <td>
                <img class="gambar-daftar" src="masak.jpg">
            </td>
            <td>
                <div class="konten-daftar">
                    <h2 style="text-align: center;">Daftar</h2>
                    <div class="error">
                        <?php
                        //cek apakah terdapat cookie dengan nama message
                        if(isset($_COOKIE["message"])){
                            //jika ada tampilkan pesannya
                            echo $_COOKIE["message"];
                        }
                        ?>
                    </div>
                    <!--multipart/form-data, file dikirim terpisah-->
                    <form method="post" action="" text-align="center" enctype="multipart/form-data"><!--Multipart untuk mengirim data berupa gambar dan tetx, action " " hasilnya dikirim ke halaman yang sama-->
                        <input type="text" name="name" placeholder="Nama" /><br />
                        <input type="text" name="email" placeholder="Email" /><br> 
                        <p class="foto-profile">Foto Profile<br></p>
                        <input type="file" name="foto" id="foto" /><br />
                        <input type="text" name="username" placeholder="Username" /><br />
                        <input type="password" name="password" placeholder="Password"/><br/><br />
                        <input type="submit" name="daftar" value="Daftar" /><br/><br>
                    </form>
                </div>
            </td>
        </tr></table>
    </div>
    <!--Footer-->
    <div class="footer">
        <p>&copy;2023 Resep Kite. All rights reserved.</p>
    </div>
</BODY>
</HTML>