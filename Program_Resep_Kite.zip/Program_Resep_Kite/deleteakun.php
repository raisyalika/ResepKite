<?php
    session_start();

    // Menyambungkan ke database resepkite
    $conn = mysqli_connect("localhost", "root", "", "resepkite")
        // Jika gagal terkoneksi, tampilkan pesan error 
        or die("Connect failed: %s\n". $conn -> error);

    // Memeriksa apakah parameter id_user ada dalam URL
    if (isset($_GET['id_user'])) {
        $id_user = $_GET['id_user'];
        
        // Query untuk mengambil informasi user berdasarkan id_user
        $query = "SELECT * FROM user WHERE id_user = $id_user";
        $result = mysqli_query($conn, $query);
        $row = mysqli_fetch_assoc($result);
    } else {
        echo "ID User tidak tersedia.";
    }

    function hapus($id_user){
        global $conn;
        mysqli_query($conn, "DELETE FROM user WHERE id_user = $id_user");
        return mysqli_affected_rows($conn);
    }

    $id_user = $_GET["id_user"];
    if( hapus($id_user) > 0){
        echo "
            <script>
                alert('Data berhasil dihapus!');
                document.location.href = 'logout.php';
            </script>
        ";
    } else {
        echo "<script>
        alert('Data gagal dihapus!');
        document.location.href = 'profile.php';
        </script>
        ";
    }
?>