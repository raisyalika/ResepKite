<?php
    session_start();

    // Menyambungkan ke database resepkite
    $conn = mysqli_connect("localhost", "root", "", "resepkite")
        // Jika gagal terkoneksi akan menampilkan pesan error
        or die("Connect failed: " . mysqli_connect_error());

    // Memeriksa apakah parameter id_resep ada dalam URL
    if (isset($_GET['id_resep'])) {
        $id_resep = $_GET['id_resep'];
        
        // Query untuk mengambil informasi resep berdasarkan id_resep
        $query = "SELECT * FROM resep WHERE id_resep = $id_resep";
        $result = mysqli_query($conn, $query);
        $row = mysqli_fetch_assoc($result);// ngambil data di $result
    } else {
        echo "ID Resep tidak tersedia.";
    }
?>

<HTML>
<HEAD>
    <link rel="icon" href="logo.png">
    <title>Resep Kite</title>
    <style>
        * {
            position: relative;
            font-family: sans-serif;
            margin: 0;
        }
        a:hover {color: dimgray;}
        img {object-fit: cover;}

        /*Layar Responsif*/
        @media (max-width: 799px) {
            .body {
                grid-template-columns: 345px 50px;
            }
        }
        /*Header */
        .header {
            text-align: center;
            display: grid;
            grid-template-columns: 1fr 1fr;
            background-color: #2c5c46;
            padding: 10px 10px;
        }
        nav ul {
            font-weight: lighter;
            font-size: large;
            list-style: none;
            margin: 0;
            padding-top: 20;
            display: flex;
            justify-content: space-between;
        }
        nav a {
            color: lightgray;
            text-decoration: none;
        }
        .header .kiri .logo {
            margin-left: 40px;
            float: left;
            width: 75;
            padding-bottom: 10;
        }
        /*Foto Resep*/
        /*gimana caranya panjang foto otomatis?*/
        .foto-resep {
            filter: brightness(50%);
            height: 350px;
            width: 100%;
        }
        .body{
            display: grid;
            grid-template-columns: 863px 300px;
            margin: 25 0 10 50;
        }
        /*Isi Resep*/
        .body .kiri .teks-konten {
            margin-bottom: 1cm;
            inline-size: 1;
        }
        .body .kiri .resep .subjudul {
            color: dimgray;
            font-weight: bold;
            font-size: 20px;
            margin: 10px;
        }
        /*Footer */
        .footer {
            text-align: center;
            background-color: #2c5c46;
            font: arial;
            color: white;
            padding: 0.5cm 2.5cm;
            clear: both; /* Menambahkan clear: both; untuk memastikan footer muncul di bawah div body */
        }
    </style>
</HEAD>
<BODY>
    <!--Header dan Navigasi Bar-->
    <div class="header">
        <div class="kiri">
            <img class="logo" src="logo.png">
        </div>
        <div class="kanan">
            <nav><ul>
                <div class="dashboard"><a href="index.php">Dashboard</a></div>
                <div class="login"><a href="login.php">Login</a></div>
                <div class="daftar"><a href="daftar.php">Daftar</a></div>
                <div></div>
            </ul></nav>
        </div>
    </div>
    <!--Foto Resep-->
    <!--foto menyesuaikan database-->
    <div><img class="foto-resep" src="fotoresep/<?= $row["fotoresep"]; ?>"></div>
    <div class="body">
        <!--Isi Resep-->
        <div class="kiri">
        <?php
            if ($row) {// 
                echo "<div class='teks-konten'>";
                    echo "<p style='font-size: 50px; font-weight: bold'>". $row['nama_resep'] . "</p>";
                echo "</div>";
                echo "<div class='resep'>";
                    echo "<div><p class='subjudul'>Kategori: " . $row['kategori'] . "</p></div>";
                    echo "<div><p class='subjudul'>Jumlah Porsi: " . $row['jmlh_porsi'] . "</p></div>";
                    echo "<div><p class='subjudul'>Bahan - Bahan:</p></div>";
                echo "</div>";
                echo "<div>";
                    echo "<ul>"; // Menambahkan tag <ul> untuk membuat list
                        $bahanList = explode("\n", $row['bahan']); // Membagi bahan menjadi array berdasarkan baris baru
                        foreach ($bahanList as $bahan) {
                            echo "<li>" . $bahan . "</li>"; // Menampilkan setiap bahan sebagai item list
                        }
                    echo "</ul>"; // Menutup tag <ul>
                echo "</div>";
                echo "<div class='resep'>";
                    echo "<div><p class='subjudul'>Langkah - Langkah:</p></div>";
                echo "</div>";
                echo "<div>";
                    echo "<ol>"; // Menambahkan tag <ol> untuk membuat list bernomor
                        $langkahList = explode("\n", $row['langkah']); // Membagi langkah menjadi array berdasarkan baris baru
                        foreach ($langkahList as $langkah) {
                            echo "<li>" . $langkah . "</li>"; // Menampilkan setiap langkah sebagai item list bernomor
                        }
                    echo "</ol>"; // Menutup tag <ol>
                echo "</div>";
            } else {
                echo "Resep tidak ditemukan.";
            }
        ?>
    </div></div>
    <!--Footer-->
    <br>
    <div class="footer">
        <p>&copy;2023 Resep Kite. All rights reserved.</p>
    </div>
</BODY>
</HTML>