<?php
    session_start();

    // Menyambungkan ke database resepkite
    $conn = mysqli_connect("localhost", "root", "", "resepkite")
        or die("Connect failed: " . mysqli_connect_error());

    // Menjalankan fungsi Query SQL pada database dan mengembalikan hasilnya dalam bentuk array
    function query($conn, $query)
    {
        $result = mysqli_query($conn, $query);
        $rows = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $rows[] = $row;
        }
        return $rows;
    }
?>

<HTML>
<HEAD>
    <link rel="icon" href="logo.png">
    <title>Resep Kite</title>
    <style>
        *{
            position: relative;
            font-family: sans-serif;
            margin: 0;
        }
        a:hover{ color: dimgray;}
        img{ object-fit: cover;}
    /*Layar Responsif*/
        @media (max-width: 799px){
            .header {padding: 5px 5px}
        }
    /*Header */
        .header{
            text-align: center;
            display: grid;
            grid-template-columns: 1fr 1fr;
            background-color: #2c5c46;
            padding: 10px 10px;
        }
        nav ul{
            font-weight: lighter;
            font-size: large;
            list-style: none;
            margin: 0;
            padding-top: 20;
            display: flex;
            justify-content: space-between;
        }
        nav a{
            color: lightgray;
            text-decoration: none;
        }
        .header .kiri .logo{
            margin-left: 40px;
            float: left;
            width: 75;
            padding-bottom: 10;
        }
    /*Judul Website */
        .body{
            display: grid;
            grid-template-columns: 1fr 1fr;
            background-color: #2c5c46;
        }
        .body .kanan{
            display: flex;
            justify-content: center;
        }
        .body .kiri{ flex: 1 1 45rem;}
        .body .kiri .kiri1{
            font-size: 50px;
            color: rgb(255, 255, 255);
            text-align: left;
            line-height: 1em;
            margin: 1.25cm 2cm 0.5cm 2cm;
        }
        .body .kiri .kiri2{
            text-align: left;
            color: lightgray;
            margin: 0cm 2cm 1cm 2cm;
        }
    /*Daftar Resep */
        .daftar-resep{ margin: 50 0 10 50}
        .daftar-resep .konten-resep{
            display: flex;
            flex-wrap: wrap;
            margin-top: 5em;
            justify-content: center;
        }
        .daftar-resep .konten-resep .konten{
            text-align: center;
            padding-bottom: 4rem;
            margin-right: 1cm;
        }
        .daftar-resep .konten-resep .konten .foto-resep{
            display: flex;
            justify-content: center;
            border-radius: 20px;
            height: 250px;
            width: 250px;
        }
        .daftar-resep .konten-resep .konten .teks-konten .judul-resep{
            font-size: 23px;
            text-decoration: none;
            color: black;
        }
        .daftar-resep .konten-resep .konten .teks-konten .owner-resep{
            font-size: 14px;
            color: dimgray;
            line-height: 2;
            margin-bottom: 10px;
        }
    /*Footer */
        .footer{
            text-align: center;
            background-color: #2c5c46;
            font: arial;
            color: white;
            padding: 0.5cm 2.5cm;
        }
    </style>
</HEAD>
<BODY>
    <!--Header dan Navigasi Bar-->
    <div class="header">
        <div class="kiri">
            <img class="logo" src="logo.png">
        </div>
        <div class="kanan">
            <nav><ul>
                <div class="dashboard"><a href="index.php">Dashboard</a></div>
                <div class="login"><a href="login.php">Login</a></div>
                <div class="daftar"><a href="daftar.php">Daftar</a></div>
                <div></div>
            </ul></nav>
        </div>
    </div>
    <!--Judul Website-->
    <div class="body">
        <div class="kiri">
            <div class="kiri1"><b>Mau makan, mau minum semua ada di mari!</b></div>
            <div class="kiri2">
                Discover 1000+ recipes in your hand with the best recipe. Help you to
                find the easiest way to cook.
            </div>
        </div>
        <div class="kanan">
            <img src="gambar1.png" width="400px" heights="300px">
        </div>
    </div>
    <!--Daftar Resep-->
    <div class="daftar-resep">
        <div class="subjudul">
            <p style="font-size: 35px; margin-bottom: 8;">
                <b>Popular Recipes Of The Week</b></p>
            <p style="color: dimgray">
                Our most popular recipes of this week</p>
        </div>
        <div class="konten-resep"> 
            <?php
            // Ambil data resep dan user dari database
            $resep = query($conn, "SELECT * FROM resep");
            foreach ($resep as $row) {
                $user = query($conn, "SELECT name FROM user WHERE id_user = $row[id_user]");

                // Tampilkan konten resep
                echo '<div class="konten">';
                echo '<img class="foto-resep" src="fotoresep/'.$row['fotoresep'].'">';
                echo '<div class="teks-konten">';
                echo '<b><a class="judul-resep" href="resepnonlogin.php?id_resep='.$row['id_resep'].'">'.$row['nama_resep'].'</a></b>';

                // Periksa apakah array $user tidak kosong sebelum mengakses indeks 0
                if (isset($user[0]['name'])) {
                    echo '<p class="owner-resep">'.$user[0]['name'].'</p>';
                }

                echo '</div>';
                echo '</div>';
            }
            ?>
        </div>
    </div>
    <!--Footer-->
    <div class="footer">
        <p>&copy;2023 Resep Kite. All rights reserved.</p>
    </div>
</BODY>
</HTML>