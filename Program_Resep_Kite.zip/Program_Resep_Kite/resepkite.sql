-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 12, 2023 at 09:11 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `resepkite`
--

-- --------------------------------------------------------

--
-- Table structure for table `resep`
--

CREATE TABLE `resep` (
  `id_resep` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `nama_resep` varchar(50) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `jmlh_porsi` varchar(50) NOT NULL,
  `bahan` text NOT NULL,
  `langkah` text NOT NULL,
  `fotoresep` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `resep`
--

INSERT INTO `resep` (`id_resep`, `id_user`, `nama_resep`, `kategori`, `jmlh_porsi`, `bahan`, `langkah`, `fotoresep`) VALUES
(8, 4, 'Mie ayam  ', 'Main Course  ', '3  ', '  300 gr mie kering/mie telur\r\n1 sdm minyak goreng\r\n1  l air kaldu ayam\r\n4 siung bawang putih, cincang\r\n1/2 sdt merica bubuk\r\nGaram secukupnya\r\n1 batang daun bawang, iris halus\r\n100 gr caisim, potong kasar\r\n4 sdm minyak goreng\r\n3 butir bawang merah, iris tipis\r\n5 siung bawang putih, cincang\r\n2 cm jahe, memarkan\r\n1 bunga lawang/pekak\r\n300 gr daging ayam, cincang kasar\r\n100 ml air\r\n2 sdm kecap manis\r\n1 sdm kecap asin\r\n1/2 sdt merica bubuk\r\n1 sdt gula pasir\r\nGaram secukupnya', '  Rebus mie telur dengan air yang dibubuhi minyak goreng sampai mie empuk dan matang. Angkat dan tiriskan\r\nDidihkan air kaldu ayam bersama bawang putih, merica bubuk, dan garam. \r\nMasukkan irisan daun bawang dan caisim, aduk dan segera angkat. Sisihkan \r\nPanaskan minyak, tumis bawang merah, bawang putih, jahe dan bunga lawang. Masukkan daging ayam, aduk sampai berubah warna. Tambahkan air, kecap manis, kecap asin, merica bubuk, dan garam. Aduk dan masak sampai tumisan matang. Angkat\r\nSiapkan mangkuk saji, atur mie di dalamnya. Beri tumisan ayam dan pangsit goreng\r\nSajikan terpisah dengan kuahnya, lengkapi dengan saus sambal dan sambal cabai rawit.', '64874572429f4.jpg'),
(12, 4, 'Siomay', 'Appetizers', '3', 'Ayam\r\nudang\r\ntepung', 'blender\r\nkukus\r\nmakan', '648747bdf1a26.jpg'),
(13, 6, 'Bir Pletok Betawi', 'Drinks', '1 pitcher', '300gram jahe (memarkan)\r\n3 batang sereh (bagian putih memarkan)\r\nkayu manis (kurang lebih 5cm)\r\n15gram kayu secang\r\n6 buah cengkeh\r\n1 buah biji pala (memarkan)\r\n2 helai daun pandan (ikat)\r\n1 cup gula pasir\r\n1 liter air', 'Panaskan 1 liter air dalam panci\r\nMasukkan jahe dan gula pasir kedalam panci, aduk hingga gula pasir larut dengan air\r\nMasukkan biji pala, cengkeh, kayu manis, sereh, daun pandan, kayu secang ke dalam panci\r\nRebus rempah-rempah tersebut selama kurang lebih 30 menit sampai air dalam panci sedikit berkurang\r\nSaring air rebusan bir pletok ke dalam sebuah wadah atau ke dalam teko\r\nTuang bir pletok pada gelas, dan bir pletok siap untuk dinikmati.', '6487528b3e4a7.jpg'),
(14, 6, 'Nasi Goreng Ala Mapala', 'Main Course', '1', '1 siung bawang putih, cincang\r\n2 buah cabai rawit, cincang\r\nGaram dan gula secukupnya\r\n1 piring nasi putih\r\n4 siung bawang merah, cincang\r\n1 batang daun seledri, cincang\r\n1 butir telur, kocok lepas\r\n1 genggam kol, potong-potong dan goreng\r\n1 sdm saus tiram', 'Tumis bawang putih dan bawang merah. Masukkan cabai lalu tumis lagi sebentar.\r\nMasukkan telur dan goreng orak arik hingga matang.\r\nMasukkan nasi dan kol goreng, aduk rata. Masukkan saus tiram dan daun seledri. Aduk rata.\r\nTambahkan gula dan garam secukupnya.\r\nAduk rata.', '6487534f9f25d.jpg'),
(15, 7, 'Soto Betawi', 'Main Course', '5', '500 g daging has luar sapi, potong-potong\r\n5 cm kayu manis\r\n5 butir cengkih\r\n5 butir kapulaga\r\n3 cm lengkuas, memarkan\r\n3 lembar daun jeruk\r\n2 lembar daun salam\r\n200 g paru sapi rebus\r\n200 g babat rebus\r\n200 g gajih rebus\r\n650 ml susu cair\r\n1 sdm merica bubuk\r\n2 sdm kaldu jamur\r\n1 sdt gula pasir\r\n2 sdm garam\r\nBumbu:\r\n10 butir bawang merah\r\n4 siung bawang putih\r\n1 sdt ketumbar\r\n2 cm jahe\r\nPelengkap:\r\nkentang rebus, potong-potong\r\ntomat merah, potong-potong\r\ndaun bawang iris halus\r\nbawang merah goreng\r\njaruk nipis\r\nemping goreng\r\nsambal rawit', 'Didihkan air, rebus daging bersama kayu manis, cengkih, kapulaga dan lengkuas hingga daging empuk.\r\nBumbu : Giling bahan bumbu dengan sedikit air hingga halus.\r\nTumis bumbu halus hingga wangi dan matang. Masukkan ke dalam rebusan daging.\r\nTambahan daun jeruk, daun salam dan serai, masak hingga bumbu meresap.\r\nMasukkan paru, babat dan gajih sapi.\r\nBumbui dengan merica, kaldu bubuk dan garam lalu didihkan kembali.\r\nTuangkan susu dan aduk hingga mendidih lalu angkat.\r\nPenyajian: Susun potongan kentang dan tomat dalam mangkuk saji.\r\nTuangi rebusan daging dan jeroan berikut kuah susunya.\r\nSajikan dengan taburan daun bawang, bawang goreng, jeruk nipis dan emping serta sambal rawit.', '648756e144ca3.jpg'),
(16, 7, 'Pempek Ikan', 'Main Course', '4', '500 gr daging tenggiri\r\n500 gr tepung sagu\r\n7 siung bawang putih\r\n1/2 sdt lada bubuk\r\nGaram dan penyedap sesuai selera\r\n350 ml air\r\n300 gr gula aren\r\n7 siung bawang putih, haluskan\r\nAsam Jawa\r\n500 ml air\r\nGaram', 'Haluskan daging tenggiri dan bawang putih, tuang ke dalam wadah.\r\nCampurkan garam, lada, penyedap, dan air.\r\nTambahkan sagu sedikit demi sedikit sampai adonan bisa dibentuk.\r\nBentuk sesuai selera. Didihkan air, rebus pempek sampai matang.\r\nMasak semua bahan cuko sampai matang, kemudian saring.\r\nCuko yang sudah diinapkan akan terasa lebih kental.', '648759dcbd1a6.jpg'),
(17, 4, 'Mie Goreng ', 'Main Course', '3', '250 gr Mie Kuning/Mie Telur\r\n3 sdm Bumbu Dasar\r\n1 bh Wortel Kupas iris seperti Korek api\r\n3 btg Daun Seledri iris\r\n4 sdm Saos Tiram\r\nsecukupnya Gula, garam, minyak goreng', '  Rebus Mie pada air mendidih, seperti pada petunjuk di Kemasan. Jangan over cook ya, Angkat dan tiriskan.\r\nTumis bumbu dasar sebentar lalu masukkan potongan Wortel aduk hingga Wortel ½ matang\r\nMasukkan Mie aduk2 hingga rata, tambahin Gulgar dan juga saos tiramnya.\r\nAduk rata kembali (tanakkan agar tidak mudah basi) gunakan api sedang saja sambil tetap diaduk2. Oh ya koreksi rasanya.\r\nSajikan dengan taburan Seledri dan bawang goreng.', '64875abdc144f.jpg'),
(18, 4, 'Es Selendang Mayang', 'Drinks', '5 ', '00 gram tepung sagu aren\r\n75 gram tepung Hun Kwe\r\n30 gram tepung beras\r\n30 gram tepung tapioka\r\n120 gula pasir\r\n8 gram garam\r\n1/2 sdt vanili bubuk\r\n3 liter air\r\nPewarna merah dan hijau\r\n500 gram gula pasir\r\n3 lembar daun pandan\r\n1,5 liter air\r\n100 ml santan instan\r\nSecukupnya garam\r\nSusu kental manis\r\nEs batu', 'Siapkan bahan-bahan untuk membuat es selendang mayang\r\nMasukkan semua tepung, gula dan air ke dalam panci. Aduk terus sampai matang atau mendidih dan adonan tepung berubah menjadi bening.\r\nMasukkan ke dalam wadah yang sudah diberi pewarna hijau. Goyang-goyang wadah agar permukaan rata. Setelah itu permukaan atas diberi pewarna merah sampai rata. Sisihkan.\r\nKuah: masukkan air dan daun pandan dalam panci. Nyalakan api. Bila sudah mendidih masukkan gula, aduk- aduk. Jika gula sudah larut, masukkan santan dan garam. Aduk-aduk kembali, lalu matikan kompor \r\nPotong-potong selendang mayang, letakkan dalam mangkuk.\r\nSiram selendang mayang dengan kuah santan. Beri susu kental manis dan es batu. Es selendang mayang siap dinikmati.', '64875ca5cd1dd.jpg'),
(19, 5, 'Es Cincau Hijau  ', 'Drinks  ', '4', 'Daun cincau hijau secukupnya\r\nSedikit garam\r\nAir matang dingin 3 gelas\r\nSantan yang sudah direbus atau matang secukupnya\r\nAir gula merah yang sudah masak secukupnya', '    Pertama kita siapkan bahan-bahan seperti santan matang dan air gula merah yang sudah dimasak. Dan sisihkan dahulu.\r\nKemudian kita membuat cincaunya, daun cincau kita cuci sampai benar-benar bersih lalu kita tiriskan.\r\nSiapkan wadah atau baskom kemudian kita campurkan air matang dingin bersama daun cincau dan beri sedikit garam, lalu kita remas-remas dengan tangan sampai air berubah warna hijau dan terlihat kental. Sebelum meremas-remas daun cincau cuci tangan kita dengan bersih kemudian gunakan sarung tangan plastik. Agar cincau steril dan higienis.\r\nSetelah di remas-remas kita saring air cincau, kemudian kita diamkan dalam lemari es kurang lebih selama 1 jam.\r\nSetelah 1 jam berlalu, air cincau akan menjadi kenyal dan padat seperti bentuk jelly.\r\nKemudian kita siapkan gelas, lalu tuangkan cincau ke dalamnya kemudian beri santan dan air gula merah secukupnya.\r\nKita boleh menambahkan es batu yang sudah di serut jika kita lebih senang yang dingin. Es cincau hijau yang segar dapat segera kita nikmati.', '64875d9a29ae4.jpg'),
(20, 5, 'Sate Taichan', 'Main Course', '2', 'Daging ayam 300gr\r\n1 siung bawang putih\r\n1 sdt lada bubuk\r\nGaram secukupnya\r\nTusuk sate secukupnya\r\nbuah cabai merah keriting\r\n5 siung bawang merah\r\npenyedap rasa atau kaldu bubuk\r\ngula pasir\r\ngaram\r\nlada bubuk\r\nIrisan tomat\r\nIrisan mentimun\r\nIrisan jeruk nipis', 'Setelah daging ayam dipotong dan cuci bersih, beri perasan jeruk nipis, bawang putih, lada, dan garam. Kemudian diremas-remas supaya bumbu meresap sempurna.\r\nDiamkan selama 60 menit supaya lebih meresap lagi.\r\nSambil menunggu, buatlah sambalnya dulu. Rebus semua bahan sambal agar lunak.\r\nKemudian angkat dan tiriskan. Uleg kasar sambalnya\r\nTumis sebentar dengan sedikit minyak goreng.\r\nTambahkan gula pasir, garam, kaldu, dan lada bubuk. Cek rasanya apakah sudah sesuai selera.\r\nMulai mengeeksekusi daging ayam. Susun di tusuk sate, minimal 4 dadu untuk setiap tusukan.\r\nLalu bakar di atas alat opembakaran hingga ayam berubah warna, ada sedikit bekas bakaran dan daging empuk.', '64875e713142a.jpg'),
(21, 5, 'Rujak Cireng', 'Appetizers', '3', '250 gr tepung tapioka atau sagu\r\n1 siung bawang putih besar, haluskan\r\n200 ml air panas\r\n1 sdt garam\r\n1 sdt kaldu jamur\r\nBawang daun\r\nGula merah\r\nAsam Jawa\r\nCabai rawit\r\nGaram\r\nAir secukupnya', 'Rebus air dan bawang putih sampai mendidih.\r\nCampur semua bahan cireng, lalu masukkan air panas.\r\nAduk adonan sampai bisa dibentuk.\r\nBentuk-bentuk cireng menjadi pipih.\r\nGoreng dengan api sedang hingga matang lalu tiriskan\r\nUlek gula merah, asam jawa, cabai rawit, garam\r\nTambahkan air secukupnya.\r\nSajikan dengan bumbu rujak.', '64875f521b0aa.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `foto` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `foto`, `name`, `email`, `password`) VALUES
(4, 'tikaaa   ', 'tika.jpg', 'tikaaa   ', 'tikaanya3@gmail.com   ', 'tika123   '),
(5, 'awwlika      ', 'rame2.jpg', 'Alika      ', 'eeee@gmail.com      ', 'alika123      '),
(6, 'alyaa ', 'alyastop.jpg', 'Alya ', 'alya132@gmail.com ', 'alya123 '),
(7, 'hanaaa', '648753e63be59.jpg', 'Hanaaa', 'hana149@gmail.com', 'hana123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `resep`
--
ALTER TABLE `resep`
  ADD PRIMARY KEY (`id_resep`),
  ADD KEY `fk_id_user` (`id_user`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `idx_id_user` (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `resep`
--
ALTER TABLE `resep`
  MODIFY `id_resep` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `resep`
--
ALTER TABLE `resep`
  ADD CONSTRAINT `fk_id_user` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
