<?php
    //session dimulai
    session_start();
?>
<HTML>
<HEAD>
    <link rel="icon" href="logo.png">
    <title>Resep Kite</title>
    <style>
        *{
            position: relative;
            font-family: sans-serif;
            margin: 0;
        }
        a:hover{ color: dimgray;}
    /*Layar Responsif*/
        @media (max-width: 799px){
            .header {padding: 5px 5px}
        }
    /*Header */
        .header{
            text-align: center;
            display: grid;
            grid-template-columns: 1fr 1fr;
            background-color: #2c5c46;
            padding: 10px 10px;
        }
        nav ul{
            font-weight: lighter;
            font-size: large;
            list-style: none;
            margin: 0;
            padding-top: 20;
            display: flex;
            justify-content: space-between;
        }
        nav a{
            color: lightgray;
            text-decoration: none;
        }
        .header .kiri .logo{
            margin-left: 40px;
            float: left;
            width: 75;
            padding-bottom: 10;
        }
    /*login*/
        .gambar-login{
            width: 650px;
            height: 400px;
            object-fit: cover;
            margin-left: 1cm;
            border-radius: 50px
        }
        .konten-login{
            width: 350px;
            background-color: #fff;
            border: 1px solid #dbdbdb;
            padding: 20px;
            border-radius: 6px;
            margin-left: 25%;
        }
        .error{
            color: red;
            margin-bottom: 15px;
        }
        /*form login*/
        form{ margin-top: 20px;}
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #dbdbdb;
            border-radius: 15px;
            margin-bottom: 15px;
        }
        input[type="submit"]{
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 15px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            background-color: #2c5c46;
            color: #fff;
        }
        input[type="submit"]:hover{
            background-color: #0080e6;
        }
        form a{
            color: #2c5c46;
            text-decoration: none;
            font-family: Arial, sans-serif;
            font-size: 14px;
            font-weight: 600;
            width: 100%;
            padding: 10px;
            cursor: pointer;
        }
    /*Footer */
        .footer{
            text-align: center;
            background-color: #2c5c46;
            font: arial;
            color: white;
            padding: 0.5cm 2.5cm;
        }
    </style>
</HEAD>
<BODY>
    <!--Header dan Navigasi Bar-->
    <div class="header">
        <div class="kiri">
            <img class="logo" src="logo.png">
        </div>
        <div class="kanan">
            <nav><ul>
                <div class="dashboard"><a href="index.php">Dashboard</a></div>
                <div class="login"><a href="login.php">Login</a></div>
                <div class="daftar"><a href="daftar.php">Daftar</a></div>
                <div></div>
            </ul></nav>
        </div>
    </div>
    <!--Login-->
    <div style="margin: 2cm 0 2cm;">
        <table><tr>
            <td>
                <img class="gambar-login" src="indofood.png">
            </td>
            <td>
                <div class="konten-login">
                    <h2 style="text-align: center";>Masuk</h2>
                    <div class="error">
                        <?php
                        //cek apakah terdapat cookie dengan nama message
                        if(isset($_COOKIE["message"])){
                            //jika ada tampilkan pesannya
                            echo $_COOKIE["message"];
                        }
                        ?>
                    </div>
                    <!--data yang disubmit akan dikirimkan ke config.php-->
                    <form method="post" action="config.php" text-align="center">
                        <input type="text" name="username" placeholder="Username" /><br />
                        <input type="password" name="password" placeholder="Password"/><br/><br />
                        <input type="submit" name="login" value="Masuk" /><br/><br>
                        <p style="text-align: center"><a href="daftar.php">Daftar</a></p>
                    </form>
                </div>
            </td>
        </tr></table>
    </div>
    <!--Footer-->
    <div class="footer">
        <p>&copy;2023 Resep Kite. All rights reserved.</p>
    </div>
</BODY>
</HTML>